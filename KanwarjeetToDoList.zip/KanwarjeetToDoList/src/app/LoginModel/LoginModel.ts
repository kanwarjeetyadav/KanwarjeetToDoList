export interface LoginModel {
    token: string;
    error: string;
  }
  