import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {LoginModel} from './LoginModel/LoginModel'

@Injectable({
  providedIn: 'root'
})
export class DBService {

  tlist: any = {};
  
  constructor(private http: HttpClient) { }
  uri = 'http://localhost:3000/todolist';
  login(email: string, password: string): Observable<LoginModel>{
    return this.http.post<LoginModel>('https://localhost:3000/login', {
      email: email,
      password: password
    });
  }
  
 addList(name, desp) {
    const obj = {
      name: name,
      desp: desp
    };
    this.http.post(`${this.uri}/add`, obj)
        .subscribe(res => console.log('Done'));
        
  }
  gettodolist() {
    return this
           .http
           .get(`${this.uri}`);
    }
    editlist(id) {
      return this
                .http
                .get(`${this.uri}/edit/${id}`);
      }

      updatelist(name, desp, id) {
console.log(name);
console.log(desp);
console.log(id);
        const obj = {
          name: name,
          desp: desp
        };
        this
          .http
          .post(`${this.uri}/update/${id}`, obj)
          .subscribe(res => console.log('Done'));
      }


      deletetodo(id) {
        return this
                  .http
                  .get(`${this.uri}/delete/${id}`);
    }
}
