import { TestBed } from '@angular/core/testing';
import { DBService } from './db.service';
import { LoginModel } from './LoginModel/LoginModel';
import {HttpErrorResponse} from '@angular/common/http';
import {HttpClientModule,HttpClient} from '@angular/common/http';

let httpClientSpy: { get: jasmine.Spy };
let dbservice: DBService;

describe('DBService', () => {
  beforeEach(() => TestBed.configureTestingModule({
     providers: [DBService],    
     imports:[HttpClientModule],
     
  }));  

  it('should be created', () => {
    const service: DBService = TestBed.get(DBService);
    expect(service).toBeTruthy();
  });
  xit('should return an error when the server returns a 404', () => {
    const errorResponse = new HttpErrorResponse({
      error: 'test 404 error',
      status: 404, statusText: 'Not Found'
        });
   
    dbservice.gettodolist().subscribe(
      heroes => fail('expected an error'),
      error  => expect(error.message).toContain('test 404 error')
    );
  });

})


