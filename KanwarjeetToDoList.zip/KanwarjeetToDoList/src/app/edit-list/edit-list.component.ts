import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import {DBService} from '../db.service'
import {ToDoList} from '../to-do-list/todolist'

@Component({
  selector: 'app-edit-list',
  templateUrl: './edit-list.component.html',
  styleUrls: ['./edit-list.component.css']
})
export class EditListComponent implements OnInit {

    adlist: any = {};
    editForm: FormGroup;
  
    constructor(private route: ActivatedRoute,
      private router: Router,
      private dbservice: DBService,
      private fb: FormBuilder) {
        this.createForm();
      }
      createForm() {
        this.editForm = this.fb.group({
               name: ['', Validators.required ],
                desp: ['', Validators.required ]
           });
        }
  
      ngOnInit() {
        this.route.params.subscribe(params => {
          this.dbservice.editlist(params['id']).subscribe(res => {
            this.adlist = res;
        });
      });
      }
      updatelist(name, desp) {
        this.route.params.subscribe(params => {
           this.dbservice.updatelist(name, desp, params['id']);
           this.router.navigate(['todolist']);
        });
     }

  }
