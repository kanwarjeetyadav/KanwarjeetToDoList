import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {ReactiveFormsModule} from '@angular/forms'
import {HttpClientModule,HttpClient} from '@angular/common/http';
import { EditListComponent } from './edit-list.component';
import {ActivatedRoute, Router } from '@angular/router';
import {DBService} from '../db.service'

xdescribe('EditListComponent', () => {
  let component: EditListComponent;
  let fixture: ComponentFixture<EditListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditListComponent ],
      imports: [ReactiveFormsModule,HttpClientModule,ActivatedRoute, Router,DBService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
