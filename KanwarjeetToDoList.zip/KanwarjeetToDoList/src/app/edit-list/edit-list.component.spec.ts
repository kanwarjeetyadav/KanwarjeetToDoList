import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {ReactiveFormsModule} from '@angular/forms'
import {HttpClientModule,HttpClient} from '@angular/common/http';
import { EditListComponent } from './edit-list.component';
import {DBService} from '../db.service'
import { RouterTestingModule } from '@angular/router/testing';

describe('EditListComponent', () => {
  let component: EditListComponent;
  let fixture: ComponentFixture<EditListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditListComponent ],
      imports: [ReactiveFormsModule,HttpClientModule,RouterTestingModule],
      providers:[DBService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Add Component Created', () => {
    expect(component).toBeTruthy();
  });

  it("Edit ToDo list", function() { 
    
    component.updatelist = jasmine.createSpy("Update"); 
    component.updatelist("test","desp"); 
    expect(component.updatelist).toHaveBeenCalled(); 
 }); 

 it("Name is required", function() { 
    
  component.updatelist = jasmine.createSpy("Update1"); 
  component.updatelist("","desp"); 
  expect(component.updatelist).toHaveBeenCalled(); 
}); 

});
