import { Component, OnInit } from '@angular/core';
import {DBService} from '../db.service'
import { FormGroup,  FormBuilder,  Validators  } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-add-list',
  templateUrl: './add-list.component.html',
  styleUrls: ['./add-list.component.css']
})
export class AddListComponent implements OnInit {
  addform: FormGroup;

  constructor(private route: ActivatedRoute,
    private router: Router,private dbservice: DBService, private fb: FormBuilder) { 
    this.createForm();
  }

  createForm() {
    this.addform = this.fb.group({
      name: ['', Validators.required ],
      desp: ['', Validators.required ]
   });
  }

  AddList(name, desp) {
    this.dbservice.addList(name, desp);
    this.router.navigate(['todolist']);
}

  ngOnInit() {
  }

}
