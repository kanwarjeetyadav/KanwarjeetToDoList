import { async, ComponentFixture, TestBed, } from '@angular/core/testing';
import {ReactiveFormsModule} from '@angular/forms'
import {DebugElement} from '@angular/core'
import {HttpClientModule,HttpClient} from '@angular/common/http';
import { AddListComponent } from './add-list.component';
import {DBService} from '../db.service'


describe('AddListComponent', () => {
  let component: AddListComponent;
  let fixture: ComponentFixture<AddListComponent>;
  let debugElement: DebugElement;
  let dbservice: DBService;
  let methodcalled;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddListComponent ],
      imports: [ReactiveFormsModule,HttpClientModule],
      providers:[DBService]
    })
    .compileComponents();
    fixture = TestBed.createComponent(AddListComponent);
    debugElement = fixture.debugElement;
    dbservice  = debugElement.injector.get(DBService);
    methodcalled = spyOn(dbservice, 'addList').and.callThrough();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  }); 
  
  xit('should add List or an error on the console', () => {
    expect(component).toBe(1);
    expect(methodcalled).toHaveBeenCalled();    
  });
  
});


