import { async, ComponentFixture, TestBed, } from '@angular/core/testing';
import {ReactiveFormsModule} from '@angular/forms'
import {DebugElement} from '@angular/core'
import {HttpClientModule,HttpClient} from '@angular/common/http';
import { AddListComponent } from './add-list.component';
import {DBService} from '../db.service'
import { RouterTestingModule } from '@angular/router/testing';


describe('AddListComponent', () => {
  let component: AddListComponent;
  let fixture: ComponentFixture<AddListComponent>;
  let debugElement: DebugElement;
  let dbservice: DBService;
  let methodcalled;  

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddListComponent ],
      imports: [ReactiveFormsModule,HttpClientModule,RouterTestingModule],
      providers:[DBService]
    })
    .compileComponents();
    fixture = TestBed.createComponent(AddListComponent);
    debugElement = fixture.debugElement;
    dbservice  = debugElement.injector.get(DBService);
    methodcalled = spyOn(dbservice, 'addList').and.callThrough();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Add Component should create', () => {
    expect(component).toBeTruthy();
  }); 
  
  it("Add ToDo Items", function() { 
    
    component.AddList = jasmine.createSpy("Add"); 
    component.AddList("test","desp"); 
    expect(component.AddList).toHaveBeenCalled(); 
 }); 
 it("Name is required", function() { 
    
  component.AddList = jasmine.createSpy("Add1"); 
  component.AddList("","desp"); 
  expect(component.AddList).toHaveBeenCalled(); 

 });
});


