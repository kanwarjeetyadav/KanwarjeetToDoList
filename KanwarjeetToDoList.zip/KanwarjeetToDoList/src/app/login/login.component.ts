import { Component, OnInit } from '@angular/core';
import {DBService} from '../db.service';
import {AuthService} from '../auth.service';
import {Router} from '@angular/router';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginform: FormGroup;
    username = 'test';
    password = 'test';
    ngOnInit() {       
    }

    constructor(private api: DBService, private customer: AuthService,
       private router: Router,private fb: FormBuilder) {
        this.createForm();
    }
    createForm() {
      this.loginform = this.fb.group({
        username: ['', Validators.required ],
        password: ['', Validators.required ]
     });
    }
  
    Login() {
      this.api.login(
        this.username,
        this.password
      )
        .subscribe(
          r => {
            if (r.token) {
              this.customer.setToken(r.token);
              this.router.navigateByUrl('/todolist');
            }
          },
          r => {
            alert(r.error.error);
          });
    }
  
  }


