import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ToDoListComponent } from './to-do-list/to-do-list.component';
import { LoginComponent } from './login/login.component';
import { AuthGuardService } from './auth-guard.service';
import {AppComponent} from './app.component'
import {AddListComponent} from './add-list/add-list.component'
import {EditListComponent} from './edit-list/edit-list.component'

const routes: Routes = [
  {path:'', component:AppComponent},
  
  {
  path: 'todolist',
  component: ToDoListComponent,
  canActivate: [AuthGuardService] 
},
{
  path: 'login',
  component: LoginComponent
},
{
  path: 'addlist',
  component: AddListComponent
},
{
  path: 'edit/:id',
  component: EditListComponent
},


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
