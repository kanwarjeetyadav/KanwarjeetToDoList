export interface ToDoList {
    _id: Number;
    name: String;
    desp: String;
}