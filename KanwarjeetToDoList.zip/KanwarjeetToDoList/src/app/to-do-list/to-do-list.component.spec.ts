import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ToDoListComponent } from './to-do-list.component';
import { RouterTestingModule } from '@angular/router/testing';
import {DBService} from '../db.service'
import {HttpClientModule,HttpClient} from '@angular/common/http';

describe('ToDoListComponent', () => {
  let component: ToDoListComponent;
  let fixture: ComponentFixture<ToDoListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ToDoListComponent ],
      imports:[RouterTestingModule,HttpClientModule],
      providers:[DBService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ToDoListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('To Do Item list should create', () => {
    expect(component).toBeTruthy();
  });

  it("Item Should be deletd", function() { 
    
    component.deletetodo = jasmine.createSpy("Delete"); 
    component.deletetodo(1); 
    expect(component.deletetodo).toHaveBeenCalled(); 
 }); 

 it("Get Item list", function() { 
    
  component.deletetodo = jasmine.createSpy("GetItem"); 
  component.deletetodo(2); 
  expect(component.deletetodo).toHaveBeenCalled(); 
}); 

});
