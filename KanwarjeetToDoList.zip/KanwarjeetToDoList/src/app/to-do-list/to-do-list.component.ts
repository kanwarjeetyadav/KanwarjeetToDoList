import { Component, OnInit } from '@angular/core';
import {DBService} from '../db.service'
import {ToDoList} from '../to-do-list/todolist'
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-to-do-list',
  templateUrl: './to-do-list.component.html',
  styleUrls: ['./to-do-list.component.css']
})
export class ToDoListComponent implements OnInit {

  todolists: ToDoList[];
  constructor(private route: ActivatedRoute,
    private router: Router,private dbservice: DBService) { }

  ngOnInit() {
    this.dbservice
    .gettodolist()
    .subscribe((data: ToDoList[]) => {
    this.todolists = data;
    })
    
  }

  deletetodo(id) {
    this.dbservice.deletetodo(id).subscribe(res => {
      this.router.navigate(['todolist']);
    });
  }

}

