const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let ToDoList = new Schema({
  id: {
    type: Number
  },

  name: {
    type: String
  },
  desp: {
    type: String
  }
},{
    collection: 'ToDoLists'
});

module.exports = mongoose.model('ToDoList', ToDoList);